###GUI.Jar###

###A simple GUI form written in Java###

###Instructions for use:
1. Download the .zip file.
2. Extract the file to your chosen location.
3. Open a Windows command prompt and cd to the .jar files extraction directory.
4. Invoke the .jar file with the command java -jar Gui.jar

###Future Improvements:
	1. Improved error checking.
	2. Resizing of the submit button.
	
	
	